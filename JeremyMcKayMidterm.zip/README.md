# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

# Calorie counting app 

This is my midterm which will be updated to use and API right now it is currently a basic Create Retrieve Update Delete application that counts calories as inputted.
